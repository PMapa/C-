#include <iostream>

using namespace std;

int main(){
	int valor;
	int n50, n10, n5, n1;
	cout << "Digite o valor (inteiro) que deseja sacar: ";
	cin >> valor;

	n50 = valor/50; //qtd de notas de 50
	cout << "Notas de 50: " << n50 << endl;
	valor = valor%50; //resto

	n10 = valor/10;
	cout << "Notas de 10: " << n10 << endl;
	valor = valor%10;

	n5 = valor/5;
	cout << "Notas de 5: " << n5 << endl;

	valor = valor%5;

	n1 = valor;
	cout << "Notas de 1: " << n1 << endl;

	return 0;
}
