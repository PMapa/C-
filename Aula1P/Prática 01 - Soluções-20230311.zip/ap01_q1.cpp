#include <iostream>
#include <math.h>

using namespace std;

int main(){
    float x, y, z;
    float a, b, c;
    cout << "Digite o valor de x: ";
    cin >> x;
    cout << "Digite o valor de y: ";
    cin >> y;
    cout << "Digite o valor de z: ";
    cin >> z;
    a = sqrt(pow(x-y,2));
    b = (pow(x,3)-sin(M_PI))/2;
    c = (pow(x+y,4))/(log10(z));
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;
    cout << "c = " << c << endl;
    return 0;
}
