#include <iostream>
#include <math.h>

using namespace std;

int main(){
    float a1, q, an;
    int n;
    cout << "Informe o primeiro termo: ";
    cin >> a1;
    cout << "Informe a raz�o: ";
    cin >> q;
    cout << "Informe o numero do termo: ";
    cin >> n;
    an = a1*pow(q, n-1);
    cout << "O termo a (" << n << ") e " << an << endl;
    return 0;
}
